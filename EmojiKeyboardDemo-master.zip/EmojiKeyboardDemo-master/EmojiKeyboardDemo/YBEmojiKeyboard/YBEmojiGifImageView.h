//
//  YBEmojiGifImageView.h
//  EmojiKeyboardDemo
//
//  Created by 杨艺博 on 2018/12/17.
//  Copyright © 2018 杨艺博. All rights reserved.
//  拷贝的 YLGifImageView 源码

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface YBEmojiGifImageView : UIImageView

@property (nonatomic, copy) NSString *runLoopMode;

@end

NS_ASSUME_NONNULL_END
