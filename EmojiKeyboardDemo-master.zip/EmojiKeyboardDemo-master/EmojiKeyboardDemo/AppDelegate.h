//
//  AppDelegate.h
//  EmojiKeyboardDemo
//
//  Created by 杨艺博 on 2018/12/12.
//  Copyright © 2018 杨艺博. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

