//
//  EmojiTextCell.m
//  EmojiKeyboardDemo
//
//  Created by 杨艺博 on 2018/12/20.
//  Copyright © 2018 杨艺博. All rights reserved.
//

#import "EmojiTextCell.h"

@implementation EmojiTextCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
