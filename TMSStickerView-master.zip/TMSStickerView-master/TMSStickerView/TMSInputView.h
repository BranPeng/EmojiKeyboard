//
//  TMSInputView.h
//  TMSStickerView
//
//  Created by TMS on 2019/1/17.
//  Copyright © 2019年 TMS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TMSInputView : UIView

// 
- (void)stickerButttonBackToOriginalState;
@end
